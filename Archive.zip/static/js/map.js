$(document).ready(function(){
    $('.list-group-item').on('click', function() {
        var $this = $(this);

        $('.active').removeClass('active');
        $this.toggleClass('active')

        // Pass clicked link element to another function
        create_request($this);
    });
});


function create_request ($this){
//    $("#loading").show();
      var uuid = $this.data('item');
//    var hasta = $("#hasta").val();
//    var tipo_edad = $("#tipo-edad").val();
//    var sexo = $("#sexo").val();
//    var fuerza = $("#fuerza").val();
//    var provincia = $("#provincia").val();
    $.get( "/locations/tracks/"+uuid, {
          format:"json",
//        tipo_edad: tipo_edad,
//        sexo: sexo,
//        fuerza: fuerza,
//        provincia: provincia
    }, function( data ) {
        try{
//            remueve_marcadores();
        }catch(err){
          //Handle errors here
        }
//        $("#loading").hide();
        initMap(data);
    });
}



function create_polyline(data){

    var points = data.points;
    var points_length = points.length;
    var coords = [];
    for (var i = 0; i < points_length; i++) {
        var lat = parseFloat(points[i].lat);
        var lng = parseFloat(points[i].lng);
        coords.push({lat: lat, lng: lng});
    }
    initMap(coords);

}


function initMap(data) {



    var coordinates = [];
    var bounds = new google.maps.LatLngBounds();

    if(typeof data === 'undefined'){
        coordinates.push(new google.maps.LatLng(45.4555729, 9.169236));
        bounds.extend(new google.maps.LatLng(45.4555729, 9.169236));
        bounds.extend(new google.maps.LatLng(55.4555729, 9.169236));
    }else{
        var points = data.points;
        var points_length = points.length;

        for (var i = 0; i < points_length; i++) {
            var lat = parseFloat(points[i].lat);
            var lng = parseFloat(points[i].lng);
            var latlng = new google.maps.LatLng(lat, lng)
            coordinates.push(latlng);
            bounds.extend(latlng);
        }
    }





    var map = new google.maps.Map(document.getElementById('map-canvas'), {
    zoom: 5,
    center: new google.maps.LatLng(45.4555729, 9.169236),
    mapTypeId: google.maps.MapTypeId.ROADMAP
    });
    var flightPath = new google.maps.Polyline({
    path :coordinates,
    geodesic: true,
    strokeColor: '#FF0000',
    strokeOpacity: 1.0,
    strokeWeight: 2
    });


    flightPath.setMap(map);
    map.fitBounds(bounds);

}