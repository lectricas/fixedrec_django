#!/bin/bash
python manage.py test --settings=parsifal.test_settings --verbosity=2